require('dotenv').config();
var fs = require('fs');
var html = fs.readFileSync('./debug_www_groups_feed.html', 'utf8');

// Extraer todos los JSON blobs
var pattern = /<script type="application\/json"[^>]*data-sjs[^>]*>([\s\S]*?)<\/script>/g;
var match;
var foundStories = 0;

while ((match = pattern.exec(html)) !== null) {
  try {
    var parsed = JSON.parse(match[1]);
    // Walk para encontrar stories
    walk(parsed);
  } catch(e) {}
}

function walk(obj, depth) {
  if (!obj || typeof obj !== 'object' || depth > 20) return;
  if (foundStories >= 3) return;
  
  if (!Array.isArray(obj)) {
    if (obj.comet_sections && obj.comet_sections.context_layout && obj.comet_sections.context_layout.story) {
      var inner = obj.comet_sections.context_layout.story;
      var innerComet = inner.comet_sections;
      if (innerComet) {
        foundStories++;
        console.log('=== Story #' + foundStories + ' ===');
        console.log('id: ' + inner.id);
        console.log('comet_sections keys: ' + Object.keys(innerComet).join(', '));
        
        // Check if 'message' exists
        if (innerComet.message) {
          console.log('HAS message section!');
          console.log('message.story keys: ' + (innerComet.message.story ? Object.keys(innerComet.message.story).join(', ') : 'N/A'));
          if (innerComet.message.story && innerComet.message.story.message) {
            console.log('TEXT: ' + innerComet.message.story.message.text);
          }
        } else {
          console.log('NO message section');
          // Show ALL keys and their types
          for (var k of Object.keys(innerComet)) {
            var v = innerComet[k];
            var hasMessage = JSON.stringify(v).includes('"message":');
            console.log('  ' + k + ': has_message_in_tree=' + hasMessage + ' (depth 0 keys: ' + (typeof v === 'object' && v !== null ? Object.keys(v).join(', ') : typeof v) + ')');
          }
        }
      }
    }
    
    for (var k of Object.keys(obj)) {
      if (foundStories < 3) walk(obj[k], depth + 1);
    }
  } else {
    for (var i = 0; i < obj.length && foundStories < 3; i++) {
      walk(obj[i], depth + 1);
    }
  }
}
