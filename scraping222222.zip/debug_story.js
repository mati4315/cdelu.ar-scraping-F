require('dotenv').config();
var fs = require('fs');
var html = fs.readFileSync('./debug_www_groups_feed.html', 'utf8');

var jsonPattern = /<script type="application\/json"[^>]*data-sjs[^>]*>([\s\S]*?)<\/script>/g;
var match;
var found = false;
while ((match = jsonPattern.exec(html)) !== null) {
  var content = match[1];
  var idx = content.indexOf('UzpfSTEwMDAwMTAzNjEwNjE3MzpWSzoxMjMzMjg3NTg1MzgwMjA4');
  if (idx >= 0) {
    found = true;
    var after = content.substring(idx, Math.min(content.length, idx + 5000));
    
    // Show structure around the message area
    var msgIdx = after.indexOf('"message"');
    if (msgIdx >= 0) {
      console.log('=== "message" section context ===');
      console.log(after.substring(Math.max(0, msgIdx - 100), msgIdx + 1000));
    } else {
      console.log('No "message" key found near this story');
      // Show all keys
      var keyMatches = after.match(/"([a-z_]+)":\{"__typename"/g) || [];
      console.log('Section keys: ' + keyMatches.join(', '));
    }
    
    // Show full structure
    console.log('\n=== Full context (1000 chars) ===');
    console.log(after.substring(0, 1000));
    break;
  }
}
if (!found) console.log('Story not found in any JSON blob');
